#include "Animal.h"

//getters

int Animal::getInaltime(){
    return this->inaltime;
}

int Animal::getGreutate(){
    return this->greutate;
}

int Animal::getVarsta(){
    return this->varsta;
}

int Animal::getNrPicioare(){
    return this->nrPicioare;
}

//setters

void Animal::setInaltime(int inaltime){
    this->inaltime = inaltime;
}

void Animal::setGreutate(int greutate){
    this->greutate = greutate;
}

void Animal::setVarsta(int varsta){
    if(varsta <= 100)
        this->varsta = varsta;
}

void Animal::setNrPicioare(int nrPicioare){
    this->nrPicioare = nrPicioare;
}

//constructors

Animal::Animal(){

}

Animal::Animal(int inaltime, int greutate, int varsta, int nrPicioare){

}

//destructor

Animal::~Animal(){
    std::cout << "Destructor Clasa Animal";
}
