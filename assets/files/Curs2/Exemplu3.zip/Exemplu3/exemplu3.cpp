#include <iostream>
#include "Animal.h"

using namespace std;

int main(){
    Animal a;
    a.prezinta();
    return 0;
}
