#ifndef ANIMAL_H
#define ANIMAL_H
#include <iostream>

class Animal {
    private:
        int inaltime;
        int greutate;
        int varsta;
        int nrPicioare;
    public:
        void prezinta(){
            std::cout << "Animalul are " << this->inaltime << "cm, "
                << this->greutate << "kg, " << this->varsta << " ani, " << this->nrPicioare << " picioare.";
        }
        //constructors
        Animal();
        Animal(int inaltime, int greutate, int varsta, int nrPicioare);

        //destructor
        ~Animal();

        //getters
        int getInaltime();
        int getGreutate();
        int getVarsta();
        int getNrPicioare();

        //setter
        void setInaltime(int inaltime);
        void setGreutate(int greutate);
        void setVarsta(int varsta);
        void setNrPicioare(int nrPicioare);
};

#endif
