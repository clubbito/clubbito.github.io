#include <iostream>

#define NUMAR 10

using namespace std;

int a[NUMAR];

int main(){
    // VECTORI
    int suma;
    cout << "Introduceti elementele vectorului: \n";
    for(int i = 0; i < 10; i++){
        cin >> a[i];
    }
    suma = 0;
    for(int i = 0; i < 10; i++){
        suma += a[i];
    }
    cout << suma << '\n';

    //BAZE
    int a = 0xffe;
    int b = 0123;
    cout << a << " " << b << '\n';

    float f = .05;
    double d = 5.e-2;
    cout << f << " " << d;
    return 0;
}
