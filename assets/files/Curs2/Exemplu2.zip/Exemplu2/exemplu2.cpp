#include <iostream>

using namespace std;

bool estePalindrom(int);

int main(){
    int n;
    cin >> n;
    if(estePalindrom(n)) cout << "este palindrom";
    else cout << "nu este palindrom";
    return 0;
}

bool estePalindrom(int x){
    int o, cf, aux;
    aux = x;
    o = 0;
    while(x != 0){
        cf = x % 10;
        o = o * 10 + cf;
        x /= 10;
    }
    if(aux == o) return true;
    else return false;
}
